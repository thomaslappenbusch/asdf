<script>
    import { M } from 'svelte-motion'
  
    let items = ['Item 1', 'Item 2', 'Item 3', 'Item 4', 'Item 5', 'Item 6'];
</script>
  
<!--<div class="flex flex-row overflow-hidden">
    
    <M.div 
      class="w-max overflow-hidden absolute right-full opacity-45 top-10" 
      animate={{ x: "290%" }} 
      transition={{ duration: 36, ease: "linear", loop: Infinity }}>
      <div class="flex flex-row gap-4 p-12">
        {#each items as item, index}
            <div class="bg-white rounded-lg shadow-2xl p-2">
            <img src={"./thumbnails/" + (index + 1) + ".jpg"} width="200" height="113" alt="Thumbnail" class="rounded-t-lg">
            <div class="px-2 py-3">
              <h3 class="text-sm font-semibold">Title</h3>
              <p class="text-gray-600 text-sm">Cooper Codes</p>
            </div>
          </div>
        {/each}
      </div>
    </M.div>

  
  <M.div 
    class="w-max overflow-hidden absolute left-full opacity-45 pt-[650px]" 
    animate={{ x: "-290%" }} 
    transition={{ duration: 36, ease: "linear", loop: Infinity }}>
    <div class="flex flex-row gap-4 p-12">
      {#each items as item, index}
          <div class="bg-white rounded-lg shadow-2xl p-2">
          <img src={"./thumbnails/" + (index + 1) + ".jpg"} width="200" height="113" alt="Thumbnail" class="rounded-t-lg">
          <div class="px-2 py-3">
            <h3 class="text-sm font-semibold">Title</h3>
            <p class="text-gray-600 text-sm">Cooper Codes</p>
          </div>
        </div>
      {/each}
    </div>
  </M.div>

</div>
-->
<div class="hero min-h-screen bg-base-200">
    <div class="hero-content text-center">
        <div class="max-w-lg">
            <h3 class="text-3xl font-bold text-left ml-7 relative top-1">the</h3>
            <h1 class="text-5xl font-bold text-center">Vauren Institute</h1>
            <p class="pt-6 pb-3">Enabling the industries top educational brands to scale. Editing services, sponsorship negotiation, course creation, video automation, and thats just the start... </p>
            <p class="pb-6">The force behind brands such as<br/><b>Cooper Codes</b>, <b>CodeLetter</b>, and <b>K8Code.com</b>.</p>
            <button class="btn btn-info text-white">Let's Build Together</button>
        </div>
    </div>
</div>


<h1 class="text-center text-4xl font-bold pt-24 pb-6">It's Simple, We Get You Results</h1>
<div class="flex w-full mx-auto justify-center">
    
<div class="stats shadow justify-center mx-auto">
  
    <div class="stat">
        <div class="stat-figure">
            <svg width="40" height="40" viewBox="0 0 15 15" fill="#000" xmlns="http://www.w3.org/2000/svg"><path d="M7.5 0.875C5.49797 0.875 3.875 2.49797 3.875 4.5C3.875 6.15288 4.98124 7.54738 6.49373 7.98351C5.2997 8.12901 4.27557 8.55134 3.50407 9.31167C2.52216 10.2794 2.02502 11.72 2.02502 13.5999C2.02502 13.8623 2.23769 14.0749 2.50002 14.0749C2.76236 14.0749 2.97502 13.8623 2.97502 13.5999C2.97502 11.8799 3.42786 10.7206 4.17091 9.9883C4.91536 9.25463 6.02674 8.87499 7.49995 8.87499C8.97317 8.87499 10.0846 9.25463 10.8291 9.98831C11.5721 10.7206 12.025 11.8799 12.025 13.5999C12.025 13.8623 12.2376 14.0749 12.5 14.0749C12.7623 14.075 12.975 13.8623 12.975 13.6C12.975 11.72 12.4778 10.2794 11.4959 9.31166C10.7244 8.55135 9.70025 8.12903 8.50625 7.98352C10.0187 7.5474 11.125 6.15289 11.125 4.5C11.125 2.49797 9.50203 0.875 7.5 0.875ZM4.825 4.5C4.825 3.02264 6.02264 1.825 7.5 1.825C8.97736 1.825 10.175 3.02264 10.175 4.5C10.175 5.97736 8.97736 7.175 7.5 7.175C6.02264 7.175 4.825 5.97736 4.825 4.5Z" fill="currentColor" fill-rule="evenodd" clip-rule="evenodd"></path></svg>        
        </div>
      <div class="stat-title">Creators</div>
      <div class="stat-value">128</div>
      <div class="stat-desc">(Min 50k Subs)</div>
    </div>
    
    <div class="stat">
      <div class="stat-title">Yearly Portfolio Revenue</div>
      <div class="stat-value">$25,200,000</div>
      <div class="stat-desc">↗︎ $516.3k (22% YoY)</div>
    </div>
  </div>
</div>
<div class="flex-col justify-center mx-auto text-center">
    <h1 class="text-center text-4xl font-bold pt-24 pb-3">Complete Creator Transformation</h1>
    <h4 class="text-center text-xl pb-12 max-w-lg mx-auto">Every single day we completely transform the lives of educational content creators.</h4> <!--<br />We offer scalability, services to sell, complete service management, and more.-->
</div>
<div class="flex flex-col w-full lg:flex-row justify-center">
    <div class="grid flex-grow card bg-base-300 rounded-box max-w-md p-6">
        <div>
            <h4 class="font-bold">Without Lappenbusch Group</h4>
            <progress class="progress progress-error" value="10" max="100"></progress>
        </div>
        <div class="py-2"></div>
        <div class="stats shadow">
            <div class="stat">
                <div class="stat-title">Monthly Revenue</div>
                <div class="stat-value text-red-500">$4,700</div> <!-- text-error -->
                <div class="stat-desc">↘ $2.3k</div><!--(-25.37% YoY)-->
            </div>
        </div>
        <div class="py-2"></div>
        <div class="stats shadow">
            <div class="stat">
                <div class="stat-title">Total Views</div>
                <div class="stat-value text-red-500">54,230</div>
                <div class="stat-desc">↘ 29.37k</div> <!--(-35.12% YoY)-->
            </div>
        </div>       
    </div>
    <div class="divider lg:divider-horizontal">OR</div> 
    <div class="grid flex-grow card bg-base-300 rounded-box max-w-md p-6">
        <div>
            <h4 class="font-bold"><span class="italic">With</span> Lappenbusch Group</h4>
            <progress class="progress progress-success" value="100" max="100"></progress>
        </div>
        <div class="py-2"></div>
        <div class="stats shadow">
            <div class="stat">
                <div class="stat-title">Monthly Revenue</div>
                <div class="stat-value underline decoration-success">$25,550</div>
                <div class="stat-desc font-bold">↗︎ $20.85k (443.62% YoY)</div>
            </div>
        </div>
        <div class="py-2"></div>
        <div class="stats shadow">
            <div class="stat">
                <div class="stat-title">Total Views</div>
                <div class="stat-value underline decoration-success">350,610</div>
                <div class="stat-desc font-bold">↗︎ 296.38k (545.82% YoY)</div>
                
            </div>
        </div>       
    </div>
</div>

<div class="py-12"></div>

<div class="flex-col justify-center mx-auto text-center">
  <h1 class="text-center text-4xl font-bold pt-16 pb-3">Our Services</h1>
  <h4 class="text-center text-xl max-w-lg mx-auto pb-12">Creating amazing content is challenging enough, let us handle <b>everything</b> else. </h4>
</div>

<div class="flex-col justify-center mx-auto text-center">
  <h1 class="flex justify-center text-center text-3xl font-bold pb-9 pt-12">
    <svg id='Down_Arrow_24' width='35' height='35' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'><rect width='24' height='24' stroke='none' fill='#000000' opacity='0'/>


      <g transform="matrix(0.71 0 0 0.71 12 12)" >
      <path style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(0,0,0); fill-rule: nonzero; opacity: 1;" transform=" translate(-15, -15)" d="M 14.984375 0.98632812 C 14.432858850921447 0.9949491932269869 13.992447346692762 1.4484681849375836 14 2 L 14 25.585938 L 10.707031 22.292969 C 10.518760077943924 22.09943608592963 10.260236119746356 21.990249950720642 9.9902344 21.990234 C 9.5833112240823 21.990340783482196 9.217025167391645 22.236989383408094 9.063903148147872 22.614004144026786 C 8.910781128904102 22.991018904645482 9.00135731768369 23.4232190448555 9.2929688 23.707031 L 14.205078 28.619141 C 14.393718336632448 28.866672308471262 14.686841847766381 29.012277000550593 14.998059358851563 29.01304255410452 C 15.309276869936745 29.01380810765845 15.60311316564122 28.869647258390437 15.792969 28.623047 C 15.794277871462644 28.621098589715807 15.795579879530992 28.61914557761328 15.796875 28.617188 L 20.707031 23.707031 C 20.968271794792877 23.45621442686285 21.07350663500295 23.083764007781856 20.982149810984033 22.73332194847753 C 20.89079298696512 22.382879889173207 20.617120110826793 22.10920701303488 20.26667805152247 22.017850189015967 C 19.916235992218144 21.92649336499705 19.54378557313715 22.031728205207123 19.292969 22.292969 L 16 25.585938 L 16 2 C 16.003701428278323 1.7296996878410038 15.897823277571275 1.4694133980471826 15.706490289327581 1.278448356915857 C 15.515157301083889 1.0874833157845312 15.254667686426398 0.9821063918050874 14.984375 0.9863281199999998 z" stroke-linecap="round" />
      </g>
      </svg>
  </h1>
</div>

<div class="flex-col justify-center mx-auto text-center max-w-xl">
  <h1 class="flex text-left text-3xl font-bold pb-3 pt-16">
    <svg id='Online_Learning_Online_Course_2_24' class="mr-2" width='35' height='35' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'><rect width='24' height='24' stroke='none' fill='#000000' opacity='0'/>


      <g transform="matrix(0.83 0 0 0.83 12 12)" >
      <g style="" >
      <g transform="matrix(1 0 0 1 2.67 -3.09)" >
      <path style="stroke: rgb(0,0,0); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-dashoffset: 0; stroke-linejoin: round; stroke-miterlimit: 4; fill: none; fill-rule: nonzero; opacity: 1;" transform=" translate(-14.67, -8.91)" d="M 11.955 6.026 C 11.955 6.026 12.449 4.497 16.672 4.3389999999999995 C 16.84560351625621 4.322626055041717 17.01855748344813 4.376258511008457 17.152438302747992 4.487982336370893 C 17.286319122047853 4.599706161733328 17.370039483073523 4.760268972652232 17.385 4.933999999999998 L 17.385 11.206999999999999 C 17.351779116465153 11.552757829816366 17.052956473346192 11.811532077465774 16.706000000000003 11.794999999999998 C 12.455000000000002 11.945999999999998 11.955000000000002 13.482999999999999 11.955000000000002 13.482999999999999 L 11.955000000000002 6.026" stroke-linecap="round" />
      </g>
      <g transform="matrix(1 0 0 1 -2.76 -3.09)" >
      <path style="stroke: rgb(0,0,0); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-dashoffset: 0; stroke-linejoin: round; stroke-miterlimit: 4; fill: none; fill-rule: nonzero; opacity: 1;" transform=" translate(-9.24, -8.91)" d="M 11.955 6.026 C 11.955 6.026 11.462 4.5 7.239 4.339 C 7.065396483743788 4.322626055041718 6.892442516551868 4.376258511008459 6.7585616972520075 4.487982336370894 C 6.624680877952148 4.59970616173333 6.54096051692648 4.760268972652234 6.526 4.934000000000001 L 6.526 11.207 C 6.5592208835348496 11.55275782981637 6.858043526653808 11.811532077465776 7.205 11.795 C 11.455 11.946 11.955 13.483 11.955 13.483 L 11.955 6.026" stroke-linecap="round" />
      </g>
      <g transform="matrix(1 0 0 1 0 0)" >
      <rect style="stroke: rgb(0,0,0); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-dashoffset: 0; stroke-linejoin: round; stroke-miterlimit: 4; fill: none; fill-rule: nonzero; opacity: 1;" x="-11.5" y="-11.5" rx="2" ry="2" width="23" height="23" />
      </g>
      <g transform="matrix(1 0 0 1 0 4.5)" >
      <line style="stroke: rgb(0,0,0); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-dashoffset: 0; stroke-linejoin: round; stroke-miterlimit: 4; fill: none; fill-rule: nonzero; opacity: 1;" x1="-11.5" y1="0" x2="11.5" y2="0" />
      </g>
      <g transform="matrix(1 0 0 1 0 8)" >
      <line style="stroke: rgb(0,0,0); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-dashoffset: 0; stroke-linejoin: round; stroke-miterlimit: 4; fill: none; fill-rule: nonzero; opacity: 1;" x1="-7.5" y1="0" x2="7.5" y2="0" />
      </g>
      <g transform="matrix(1 0 0 1 -4.5 8)" >
      <line style="stroke: rgb(0,0,0); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-dashoffset: 0; stroke-linejoin: round; stroke-miterlimit: 4; fill: none; fill-rule: nonzero; opacity: 1;" x1="0" y1="-1" x2="0" y2="1" />
      </g>
      </g>
      </g>
      </svg> Complete Course Creation
  </h1>
  <h4 class="text-left text-xl pb-3 mx-auto">Building an impressive paid educational product is difficult (to impossible) when managing full time content creation. Our in house team creates industry leading content, projects, and more for your paid product.</h4>
  <h4 class="text-left text-xl pb-3 mx-auto"><b>Content Specialties</b>: Next.js 14, SvelteKit 2.0, Supabase, OpenAI APIs, Clerk, and more...</h4>
  <h4 class="text-left text-xl mx-auto">We create scripts, learning documents, and more for you to easily explain content to your audience. Building an amazing paid product has never been easier.</h4>
</div>


<div class="divider max-w-lg mx-auto py-8"></div>

<div class="flex-col justify-center mx-auto text-center max-w-xl">
  <h1 class="flex text-left text-3xl font-bold pb-3">
    <svg class="mr-2" id='Workflow_Coaching_User_Whistle_24' width='35' height='35' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'><rect width='24' height='24' stroke='none' fill='#000000' opacity='0'/>
      <g transform="matrix(0.83 0 0 0.83 12 12)" >
      <g style="" >
      <g transform="matrix(1 0 0 1 -4.1 7.73)" >
      <path style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(0,0,0); fill-rule: nonzero; opacity: 1;" transform=" translate(-7.9, -19.73)" d="M 13.37 21.33 C 13.005785652462214 20.393168612562643 12.936013997783203 19.367525288781202 13.169999999999998 18.39 L 11.58 17.169999999999998 C 10.309551307720035 17.212981012165844 9.085733501014511 16.68901111288773 8.24 15.739999999999998 C 8.070448745741082 15.53307308365115 7.8045908732123985 15.43052790424723 7.539999999999999 15.469999999999999 C 5.201449219482033 15.80481570046418 2.976523226763371 16.692729155185496 1.0499999999999998 18.06 C 0.404184760616097 18.585072384301707 0.03547719836890306 19.377793643133174 0.050000000000000266 20.209999999999997 L 0.04999999999999982 23.209999999999997 C 0.0325987538943153 23.6188429606697 0.3420349864433509 23.968063851689326 0.7500000000000001 24 C 1.1619620636246077 23.9946141876919 1.4946141876918997 23.661962063624607 1.5 23.25 L 1.5 20.2 C 1.5093786158947788 19.822682611115972 1.694288960895024 19.471352955615504 1.9999999999999991 19.25 C 2.3502233657608977 18.98877997902733 2.7177303852459405 18.751570902814255 3.099999999999997 18.54 C 4.068276395456329 19.91464287355027 4.527903589559761 21.58344314752581 4.4 23.260000000000005 C 4.405471192248541 23.670303064007854 4.739660461387968 24.000036476225418 5.15 24 L 15.75 24 C 14.654583182050922 23.43391021565783 13.806971724048923 22.48301836991609 13.37 21.33 Z" stroke-linecap="round" />
      </g>
      <g transform="matrix(1 0 0 1 8.95 1.83)" >
      <path style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(0,0,0); fill-rule: nonzero; opacity: 1;" transform=" translate(-20.95, -13.83)" d="M 21.37 12.9 C 20.991378576990517 12.735262195662429 20.550211254278903 12.898494105065726 20.37 13.27 L 20.150000000000002 13.76 C 19.97958927548103 14.13844444547448 20.144302589512325 14.58361556447798 20.520000000000003 14.76 C 20.701524056119368 14.844640514748303 20.90936149952251 14.853159061654084 21.097203309083163 14.783657592116644 C 21.28504511864381 14.714156122579205 21.43728434169859 14.57240920908399 21.520000000000003 14.39 L 21.750000000000004 13.9 C 21.913357808687547 13.518725689597165 21.745338532872438 13.07656970061004 21.37 12.9 Z" stroke-linecap="round" />
      </g>
      <g transform="matrix(1 0 0 1 10.73 3.55)" >
      <path style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(0,0,0); fill-rule: nonzero; opacity: 1;" transform=" translate(-22.73, -15.55)" d="M 23.81 15.16 C 23.743462065926238 14.963117977711926 23.59720197292275 14.8032893462861 23.4069797164812 14.719591553451817 C 23.21675746003965 14.635893760617535 23.000107548299752 14.636041989956272 22.81 14.72 L 22.099999999999998 14.98 C 21.710639251369287 15.123594034956007 21.51140596504399 15.555639251369291 21.654999999999998 15.945 C 21.798594034956004 16.33436074863071 22.23063925136929 16.533594034956007 22.619999999999997 16.39 L 23.33 16.12 C 23.524107875011406 16.06084590015877 23.68540772258394 15.924576828691876 23.7761569095439 15.743078454771952 C 23.866906096503865 15.561580080852027 23.87914144513386 15.350778759913865 23.81 15.16 Z" stroke-linecap="round" />
      </g>
      <g transform="matrix(1 0 0 1 -0.36 -4.53)" >
      <path style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(0,0,0); fill-rule: nonzero; opacity: 1;" transform=" translate(-11.64, -7.47)" d="M 10.68 14.47 L 11.129999999999999 13.47 C 8.31809848900346 13.170865957289687 6.278522707128683 10.652705507299556 6.57 7.8400000000000025 C 9.929735529106562 7.100002159360752 13.410264470893438 7.100002159360761 16.77 7.840000000000007 C 16.967690447432826 9.633895552484912 16.208199129128868 11.399712867541618 14.770000000000003 12.489999999999998 L 16.27 13.18 C 17.59984605835761 11.882482824574842 18.32523475968981 10.08714578877765 18.27 8.23 L 18.27 8.23 C 18.66699160852589 8.340178997999114 19.079480242369332 8.113975553633356 19.2 7.720000000000001 C 19.258534406199253 7.529017167808256 19.237373226014398 7.3224820072721695 19.141326121893922 7.147337287993655 C 19.045279017773446 6.97219256871514 18.882504820876797 6.843316159279072 18.689999999999998 6.790000000000001 L 18.069999999999997 6.620000000000001 L 17.189999999999998 2.2200000000000006 C 17.11392602611977 1.8253265600562816 16.82497097844931 1.505549640634304 16.439999999999998 1.3900000000000006 L 12 0.05 C 11.79928064766862 -0.02011737671340999 11.58071935233138 -0.020117376713409726 11.38 0.050000000000000336 L 6.85 1.4 C 6.465029021550687 1.5155496406343036 6.176073973880225 1.8353265600562811 6.1 2.2300000000000004 L 5.22 6.630000000000001 L 4.6 6.8 C 4.4074951791232015 6.853316159279071 4.244720982226551 6.982192568715139 4.1486738781060755 7.157337287993654 C 4.052626773985599 7.332482007272169 4.031465593800746 7.539017167808255 4.09 7.7299999999999995 C 4.210361125809591 8.114202632338664 4.609463331376037 8.337875296996783 5 8.24 L 5 8.24 C 4.9251285282463195 11.522368355297175 7.256963430049918 14.368141368427251 10.489999999999998 14.940000000000001 C 10.532054526797625 14.775549559195598 10.595956528500134 14.617476186563074 10.68 14.47 Z" stroke-linecap="round" />
      </g>
      <g transform="matrix(1 0 0 1 5.66 6.25)" >
      <path style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(0,0,0); fill-rule: nonzero; opacity: 1;" transform=" translate(-17.66, -18.25)" d="M 22.9 21.06 L 21.479999999999997 20.41 C 21.837574485052368 18.960819611765444 21.24500829237081 17.443369699425507 20 16.62 L 19.4 17.19 L 18 16.53 L 18.05 15.660000000000002 L 13.350000000000001 13.500000000000002 C 13.21885517125193 13.439286286236765 13.06884653062147 13.433673233824035 12.93353118338863 13.484416489036349 C 12.798215836155794 13.535159744248663 12.688886401650803 13.638024574837187 12.63 13.770000000000001 L 12 15.1 C 11.891008923512187 15.330202706107526 11.957690475086919 15.605264106353298 12.16 15.76 L 15 17.87 L 14.9 18.07 C 14.503952357286716 18.929328239820542 14.470543811331694 19.91191887675321 14.807309166255862 20.796163104766386 C 15.14407452118003 21.680407332779566 15.822652549853949 22.39183712533227 16.69 22.77 C 18.1422265381552 23.391509111221303 19.830247255201765 22.98475713121008 20.840000000000003 21.77 L 22.310000000000002 22.44 C 22.406599878188047 22.48679200297366 22.51266651663558 22.510742534236005 22.62 22.51 C 22.972464976906227 22.511707394641558 23.278561144458394 22.267752530393942 23.35553171061856 21.923790312865695 C 23.432502276778727 21.579828095337444 23.259576130590183 21.22867942661638 22.94 21.080000000000002 Z M 17.64 20.58 C 17.188872673872012 20.26903245046557 17.02895597592587 19.677330274732235 17.26201998939309 19.18144939501475 C 17.49508400286031 18.685568515297263 18.052698176469264 18.431105849194825 18.580000000000002 18.58 C 19.007544122139326 18.70072558098022 19.323316305604 19.062743214022742 19.384850927981546 19.50272290960852 C 19.446385550359093 19.94270260519429 19.2420488419751 20.37746155920278 18.864030545517593 20.610851382936076 C 18.48601224906008 20.84424120666937 18.0057807123271 20.832137091218996 17.64 20.58 Z" stroke-linecap="round" />
      </g>
      <g transform="matrix(1 0 0 1 1.45 -2.71)" >
      <circle style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(0,0,0); fill-rule: nonzero; opacity: 1;" cx="0" cy="0" r="0.89" />
      </g>
      <g transform="matrix(1 0 0 1 -2.11 -2.71)" >
      <circle style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(0,0,0); fill-rule: nonzero; opacity: 1;" cx="0" cy="0" r="0.89" />
      </g>
      </g>
      </g>
      </svg>    Coaching Offer Setup
  </h1>
  <h4 class="text-left text-xl mx-auto">Get high quality, high pay (+$200/hr) coaching clients. No input required, we handle everything for you. From outreach, negotation, customer support, and more.</h4>
</div>

<div class="divider max-w-lg mx-auto py-8"></div>

<div class="flex-col justify-center mx-auto text-center max-w-xl">
  <h1 class="flex text-left text-3xl font-bold pb-3">
    <svg class="mr-2" id='Video_Editing_24' width='35' height='35' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'><rect width='24' height='24' stroke='none' fill='#000000' opacity='0'/>


      <g transform="matrix(0.77 0 0 0.77 12 12)" >
      <path style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(0,0,0); fill-rule: nonzero; opacity: 1;" transform=" translate(-15, -17.5)" d="M 3 5 C 2.448 5 2 5.448 2 6 L 2 24 C 2 24.552 2.448 25 3 25 L 13 25 L 11 23 L 4 23 L 4 7 L 26 7 L 26 23 L 21 23 L 23 25 L 27 25 C 27.552 25 28 24.552 28 24 L 28 6 C 28 5.448 27.552 5 27 5 L 3 5 z M 6 9 L 6 11 L 8 11 L 8 9 L 6 9 z M 10 9 L 10 11 L 12 11 L 12 9 L 10 9 z M 14 9 L 14 11 L 16 11 L 16 9 L 14 9 z M 18 9 L 18 11 L 20 11 L 20 9 L 18 9 z M 22 9 L 22 11 L 24 11 L 24 9 L 22 9 z M 9.2382812 16 C 9.103388646504134 16.009848873561424 8.999213599354364 16.12256266405676 9 16.257812 C 9.000041332405274 16.287796166477783 9.005329422926549 16.317541802574116 9.015625 16.345703 C 9.016264959233895 16.34701050796061 9.016916016066048 16.348312554955847 9.0175781 16.349609 L 9.5917969 17.978516 L 10.978516 16.59375 L 9.3613281 16.021484 L 9.3574219 16.019531 C 9.356770869016673 16.019528526191063 9.356119830983326 16.019528526191063 9.3554688 16.019531 C 9.324501561211731 16.00671546838889 9.291326694529547 16.000080583377173 9.2578125 16 C 9.251304418462825 15.999752523034632 9.244789281537175 15.999752523034632 9.2382812 16 z M 13.113281 17.542969 L 12.857422 18.314453 L 11.570312 18.572266 L 11.314453 19.857422 L 10.542969 20.115234 L 18.371094 27.943359 L 20.943359 25.371094 L 13.113281 17.542969 z M 6 19 L 6 21 L 8 21 L 8 19 L 6 19 z M 18 19 L 20 21 L 20 19 L 18 19 z M 22 19 L 22 21 L 24 21 L 24 19 L 22 19 z M 21.970703 26.400391 L 19.400391 28.972656 L 20.126953 29.699219 C 20.528953 30.101219 21.179078 30.101219 21.580078 29.699219 L 22.697266 28.582031 C 23.099266 28.180031 23.099266 27.529906 22.697266 27.128906 L 21.970703 26.400391 z" stroke-linecap="round" />
      </g>
      </svg>    Long Form Content Editing
  </h1>
  <h4 class="text-left text-xl mx-auto">Editing down hours of tutorial content can be draining. Our team of editors and educational specialists work together to turn your long video files into amazing long form content.</h4>
</div>

<div class="divider max-w-lg mx-auto py-8"></div>

<div class="flex-col justify-center mx-auto text-center max-w-xl">
  <h1 class="flex text-left text-3xl font-bold pb-3">
    <svg class="mr-2" id='YouTube_Shorts_24' width='35' height='35' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'><rect width='30' height='30' stroke='none' fill='#000000' opacity='0'/>
      <g transform="matrix(0.42 0 0 0.42 12 12)" >
      <g style="" >
      <g transform="matrix(1 0 0 1 0 0)" >
      <path style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(255,61,0); fill-rule: nonzero; opacity: 1;" transform=" translate(-24, -24)" d="M 29.103 2.631 C 33.32 0.43299999999999983 38.541000000000004 2.034 40.761 6.208 C 42.981 10.381 41.361000000000004 15.545 37.144000000000005 17.742 L 33.676 19.565 C 36.663000000000004 19.674000000000003 39.512 21.315 41.004000000000005 24.12 C 43.224000000000004 28.293 41.608000000000004 33.457 37.38700000000001 35.654 L 18.897 45.37 C 14.68 47.568 9.458999999999998 45.967 7.238999999999999 41.793 C 5.019 37.619 6.638999999999999 32.456 10.855999999999998 30.259 L 14.323999999999998 28.436 C 11.336999999999998 28.326999999999998 8.487999999999998 26.686 6.995999999999998 23.881 C 4.775999999999998 19.708 6.395999999999998 14.544 10.612999999999998 12.347 C 10.612 12.346 29.103 2.631 29.103 2.631 z M 19.122 17.12 L 30.314 24.03 L 19.122 30.907 C 19.122 30.907 19.122 17.12 19.122 17.12 z" stroke-linecap="round" />
      </g>
      <g transform="matrix(1 0 0 1 0.72 0.01)" >
      <path style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;" transform=" translate(-24.72, -24.01)" d="M 19.122 17.12 L 19.122 30.907000000000004 L 30.314 24.030000000000005 L 19.122 17.12 z" stroke-linecap="round" />
      </g>
      </g>
      </g>
      </svg>    Short Form Content Editing
  </h1>
  <h4 class="text-left text-xl mx-auto">Your AI edited shorts suck, they aren't unique, and they don't perform. Our in house editing team changes that, focusing on the latest trends and styles to get you maximum engagement.</h4>
</div>

<div class="divider max-w-lg mx-auto py-8"></div>

<div class="flex-col justify-center mx-auto text-center max-w-xl">
  <h1 class="flex text-left text-3xl font-bold pb-3">
    <svg class="mr-2" id='Email_Send_24' width='35' height='35' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'><rect width='24' height='24' stroke='none' fill='#000000' opacity='0'/>


      <g transform="matrix(0.42 0 0 0.42 12 12)" >
      <g style="" >
      <g transform="matrix(1 0 0 1 0 0)" >
      <path style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(144,202,249); fill-rule: nonzero; opacity: 1;" transform=" translate(-24, -24)" d="M 3 19.5 L 10.982 28.996 L 16 32 L 18.992 37.004 L 28.5 45 L 45 3 z" stroke-linecap="round" />
      </g>
      <g transform="matrix(1 0 0 1 2.5 -2.5)" >
      <path style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(25,118,210); fill-rule: nonzero; opacity: 1;" transform=" translate(-26.5, -21.5)" d="M 19 37 L 16 32 L 11 29 L 42 6 z" stroke-linecap="round" />
      </g>
      </g>
      </g>
      </svg>    Newsletter Management
  </h1>
  <h4 class="text-left text-xl mx-auto">Start a newsletter to connect with your audience, or to enable a new side income. We handle the entire newsletter process: writing, research, branding, landing page, message, advertisers, and more.</h4>
</div>

<div class="divider max-w-lg mx-auto py-8"></div>

<div class="flex-col justify-center mx-auto text-center max-w-xl">
  <h1 class="flex text-left text-3xl font-bold pb-3">
    <svg class="mr-2" id='Online_Support_24' width='35' height='35' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'><rect width='24' height='24' stroke='none' fill='#000000' opacity='0'/>


      <g transform="matrix(0.77 0 0 0.77 12 12)" >
      <path style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(0,0,0); fill-rule: nonzero; opacity: 1;" transform=" translate(-16.5, -16)" d="M 16 3 C 9.953125 3 5 7.953125 5 14 L 5 15.53125 C 4.394531 16.179688 4 17.03125 4 18 C 4 19.59375 5.027344 20.808594 6.375 21.46875 C 7.511719 25.734375 11.355469 29 16 29 C 19.273438 29 22.164063 27.46875 23.96875 25 L 24 25 C 25.933594 25 27.535156 23.636719 27.90625 21.8125 C 28.101563 21.722656 28.28125 21.59375 28.4375 21.4375 C 28.816406 21.058594 29 20.523438 29 20 L 29 15 C 29 14.476563 28.816406 13.941406 28.4375 13.5625 C 28.058594 13.183594 27.523438 13 27 13 L 26.9375 13 C 26.429688 7.417969 21.710938 3 16 3 Z M 16 5 C 20.367188 5 24.003906 8.144531 24.8125 12.28125 C 24.632813 12.210938 24.449219 12.164063 24.28125 12.125 C 23.570313 11.957031 22.882813 11.910156 22.25 11.75 C 21.617188 11.589844 21.105469 11.363281 20.71875 10.875 C 20.332031 10.386719 20 9.554688 20 8 L 18 8 C 18 9.972656 17.433594 10.765625 16.59375 11.28125 C 15.753906 11.796875 14.417969 11.96875 12.96875 12 C 11.519531 12.03125 10.027344 11.917969 8.6875 12.1875 C 8.121094 12.300781 7.542969 12.480469 7.0625 12.84375 C 7.636719 8.433594 11.441406 5 16 5 Z M 18.9375 11.78125 C 19.011719 11.894531 19.074219 12.023438 19.15625 12.125 C 19.894531 13.054688 20.882813 13.472656 21.75 13.6875 C 22.617188 13.902344 23.429688 13.964844 23.84375 14.0625 C 23.972656 14.09375 23.96875 14.105469 24 14.125 L 24 22 L 25.75 22 C 25.429688 22.613281 24.808594 23 24 23 L 17.90625 23 C 17.703125 22.414063 17.15625 22 16.5 22 C 15.671875 22 15 22.671875 15 23.5 C 15 24.328125 15.671875 25 16.5 25 L 21.3125 25 C 19.921875 26.257813 18.066406 27 16 27 C 12.179688 27 8.988281 24.238281 8.1875 20.6875 L 8.0625 20.125 L 7.5 19.9375 C 6.570313 19.652344 6 18.972656 6 18 C 6 17.160156 6.667969 16.316406 7.25 16.15625 L 8 15.96875 L 8 15.1875 C 8 14.746094 8.089844 14.628906 8.21875 14.5 C 8.347656 14.371094 8.609375 14.246094 9.0625 14.15625 C 9.972656 13.972656 11.480469 14.03125 13.03125 14 C 14.582031 13.96875 16.246094 13.832031 17.65625 12.96875 C 18.140625 12.671875 18.582031 12.269531 18.9375 11.78125 Z M 26 15 L 27 15 L 27 20 L 26 20 Z M 12.5 16 C 11.671875 16 11 16.671875 11 17.5 C 11 18.328125 11.671875 19 12.5 19 C 13.328125 19 14 18.328125 14 17.5 C 14 16.671875 13.328125 16 12.5 16 Z M 19.5 16 C 18.671875 16 18 16.671875 18 17.5 C 18 18.328125 18.671875 19 19.5 19 C 20.328125 19 21 18.328125 21 17.5 C 21 16.671875 20.328125 16 19.5 16 Z" stroke-linecap="round" />
      </g>
      </svg>Tailored Customer Support
  </h1>
  <h4 class="text-left text-xl mx-auto">One of the most difficult aspects of paid products is an expecation of customer support. We offer complete support teams, with massive technical depth relating to your course content. </h4>
</div>

<div class="divider max-w-lg mx-auto py-8"></div>

<div class="flex-col justify-center mx-auto text-center max-w-xl">
  <h4 class="text-center text-xl mx-auto pb-12">And more... we offer so much its hard to put it all here...</h4>
</div>

<div class="flex-col justify-center mx-auto text-center">
  <h1 class="text-center text-5xl font-bold pt-12 pb-3">Interested In Working With Us?</h1>
  <h4 class="text-center text-2xl max-w-2xl mx-auto pb-12">We have the best offer in the online education industry. <br /> Fill out some details below and we will be in touch.</h4>
</div>

<div class="flex items-center justify-center"> 
  <div class="flex-col justify-center mx-auto  w-full">
    <div class="grid card bg-base-200 max-w-2xl p-6 mx-auto rounded-lg">
      <h3 class="font-bold">Application For The Lappenbusch Group</h3>
      <p class="text-sm pb-6 italic">100% Confidential</p>
      <label class="form-control pb-3">
        <div class="label">
          <span class="label-text">What is your name?</span>
        </div>
        <input type="text" placeholder="ex: John Doe" class="input input-bordered w-full max-w-2xl" />
      </label>
      <label class="form-control pb-3">
        <div class="label">
          <span class="label-text">What is the name of your channel / brand / website?</span>
        </div>
        <input type="text" placeholder="ex: John Doe Education" class="input input-bordered w-full max-w-2xl" />
      </label>
      <label class="form-control pb-3">
        <div class="label">
          <span class="label-text">Why are you interested in partnering with The Lappenbusch Group?</span>
        </div>
        <textarea placeholder="increase income, increase free time, spend more time with family, friends, etc." class="textarea textarea-bordered textarea-lg w-full max-w-2xl max-h-[400px] min-h-[100px] h-[150px]" ></textarea>
        <span class="label-text text-sm text-gray-400">responses are confidential</span>
      </label>
      <label class="form-control pb-3">
        <div class="label">
          <span class="label-text">What are some of the issues your business is facing that you need help with?</span>
        </div>
        <textarea placeholder="scaling, outreach, customer support, course creation..." class="textarea textarea-bordered textarea-lg w-full max-w-2xl max-h-[400px] min-h-[100px] h-[150px]" ></textarea>
        <span class="label-text text-sm text-gray-400">responses are confidential</span>
      </label>
      <label class="form-control pb-3">
        <div class="label">
          <span class="label-text">Which of these services interest you?</span>
        </div>
        <div class="form-control">
          <label class="flex label cursor-pointer justify-start">
            <input type="checkbox" checked={false} class="checkbox" />
            <span class="ml-4">Course Creation</span> 
          </label>
          <label class="flex label cursor-pointer justify-start">
            <input type="checkbox" checked={false} class="checkbox" />
            <span class="ml-4">Coaching Offer Setup</span> 
          </label>
          <label class="flex label cursor-pointer justify-start">
            <input type="checkbox" checked={false} class="checkbox" />
            <span class="ml-4">Long Form Content Editing</span> 
          </label>
          <label class="flex label cursor-pointer justify-start">
            <input type="checkbox" checked={false} class="checkbox" />
            <span class="ml-4">Short Form Content Editing</span> 
          </label>
          <label class="flex label cursor-pointer justify-start">
            <input type="checkbox" checked={false} class="checkbox" />
            <span class="ml-4">Newsletter Management</span> 
          </label>
          <label class="flex label cursor-pointer justify-start">
            <input type="checkbox" checked={false} class="checkbox" />
            <span class="ml-4">Tailored Customer Support</span> 
          </label>
        </div>
       
      </label>
      <label class="form-control pb-12">
        <div class="label">
          <span class="label-text">What is a good email for us to reach you?</span>
        </div>
        <input type="text" placeholder="ex: john@lappenbuschgroup.com" class="input input-bordered w-full max-w-2xl" />
      </label>
      <div class="flex justify-center">
        <button class="btn btn-info max-w-sm text-white">Submit Application</button>
      </div>
    </div>
  </div>
</div>
<div class=" max-w-lg mx-auto py-24"></div>

<footer class="footer p-10 bg-neutral text-neutral-content">
    <nav>
      <h6 class="footer-title">Services</h6> 
      <a class="link link-hover" href="https://google.com">Branding</a>
      <a class="link link-hover" href="https://google.com">Design</a>
      <a class="link link-hover" href="https://google.com">Marketing</a>
      <a class="link link-hover" href="https://google.com">Advertisement</a>
    </nav> 
    <nav>
      <h6 class="footer-title">Company</h6> 
      <a class="link link-hover" href="https://google.com">About us</a>
      <a class="link link-hover" href="https://google.com">Contact</a>
      <a class="link link-hover" href="https://google.com">Jobs</a>
      <a class="link link-hover" href="https://google.com">Press kit</a>
    </nav> 
    <nav>
      <h6 class="footer-title">Legal</h6> 
      <a class="link link-hover" href="https://google.com">Terms of use</a>
      <a class="link link-hover" href="https://google.com">Privacy policy</a>
      <a class="link link-hover" href="https://google.com">Cookie policy</a>
    </nav>
</footer>