<script>import "../app.pcss";</script>
<div class="navbar bg-base-200 shadow-sm fixed z-10"> <!-- bg-base-100 shadow-md -->
    <div class="navbar-center flex-1 max-w-2xl mx-auto justify-center">
        <a class="btn btn-ghost text-lg">TLG</a> 
        <ul class="menu menu-horizontal">
            <li><a href="https://google.com">Contact</a></li>
            <li><a href="https://google.com">Business Consulting</a></li>
            <li><a href="https://google.com">The Team</a></li>
        </ul>
    </div>
</div>
<slot></slot>